<?php

session_start();

require_once "../includes/db.php";


/* ONLY ADMIN */

if(!isset($_SESSION['user_id']) || $_SESSION['role']!='admin'){

    header("Location: ../auth/login.php");
    exit();

}


function h($value){

    return htmlspecialchars($value ?? '',ENT_QUOTES,'UTF-8');

}



/*
==============================
GET STAFF PERFORMANCE DATA
==============================
*/


$sql = "

SELECT

sr.id AS staff_record_id,

sr.user_id,

sr.staff_id,

sr.full_name,

sr.department,

sr.designation,


COALESCE(u.availability,'Available') AS availability,


COALESCE(sp.task_completed,0) AS task_completed,

COALESCE(sp.task_pending,0) AS task_pending,

COALESCE(sp.total_tasks,0) AS total_tasks,

COALESCE(sp.rating,5) AS rating,

COALESCE(sp.performance_status,'Good') AS performance_status,

COALESCE(sp.feedback,'') AS feedback,


COALESCE(sp.complaints_resolved,0) AS solved_complaints


FROM staff_records sr


LEFT JOIN users u

ON sr.user_id = u.id



LEFT JOIN staff_performance sp

ON sr.id = sp.staff_id



ORDER BY sr.id DESC

";


$result=mysqli_query($conn,$sql);


?>


<!DOCTYPE html>
<html>

<head>

<title>
Staff Performance
</title>


<style>


body{

font-family:Segoe UI;
background:#f1f5f9;
margin:0;

}


.container{

width:95%;
margin:auto;

}



.header{

background:white;
margin-top:30px;
padding:25px;
border-radius:20px;
box-shadow:0 5px 20px #ddd;

}



.staff-box{

background:white;
margin-top:25px;
padding:25px;
border-radius:20px;
box-shadow:0 5px 20px #ddd;

}



.cards{

display:grid;
grid-template-columns:repeat(4,1fr);
gap:20px;
margin-top:20px;

}



.card{

background:#f8fafc;
padding:20px;
border-radius:15px;
text-align:center;

}



.card h2{

color:#2563eb;

}



.badge{

background:#22c55e;
color:white;
padding:8px 15px;
border-radius:20px;

}



.progress{

height:15px;
background:#ddd;
border-radius:20px;
overflow:hidden;

}


.bar{

height:100%;
background:#2563eb;

}



.feedback{

margin-top:20px;
background:#f8fafc;
padding:20px;
border-radius:15px;

}



select,textarea{

width:100%;
padding:12px;
border-radius:10px;
margin-top:8px;

}



textarea{

height:100px;

}



button{

background:#2563eb;
color:white;
border:0;
padding:12px 25px;
border-radius:10px;
cursor:pointer;

}



@media(max-width:800px){

.cards{

grid-template-columns:1fr 1fr;

}

}



</style>


</head>


<body>


<div class="container">



<div class="header">


<h1>
📊 Staff Performance Management
</h1>


<p>
Admin can monitor staff activities
</p>


</div>




<?php while($staff=mysqli_fetch_assoc($result)){



/*
=========================
COMPLAINT AUTO COUNT
=========================
*/


$cid=$staff['user_id'];


$csql="

SELECT

COUNT(*) total,

SUM(status='Solved') AS solved


FROM complaints

WHERE assigned_staff_id=?


";


$stmt=mysqli_prepare($conn,$csql);

mysqli_stmt_bind_param($stmt,"i",$cid);

mysqli_stmt_execute($stmt);


$cresult=mysqli_stmt_get_result($stmt);


$complaint=mysqli_fetch_assoc($cresult);



$total_complaint=$complaint['total'] ?? 0;

$solved_complaint=$complaint['solved'] ?? 0;



$task_percent=0;


if($staff['total_tasks']>0){

$task_percent=round(
($staff['task_completed']/$staff['total_tasks'])*100
);

}



$complaint_percent=0;


if($total_complaint>0){

$complaint_percent=round(
($solved_complaint/$total_complaint)*100
);

}



?>



<div class="staff-box">



<h2>
👤 <?=h($staff['full_name'])?>
</h2>


<p>
Staff ID :
<?=h($staff['staff_id'])?>
</p>


<p>
Department :
<?=h($staff['department'])?>
</p>


<p>
Designation :
<?=h($staff['designation'])?>
</p>



<span class="badge">

<?=h($staff['availability'])?>

</span>




<div class="cards">


<div class="card">

<h3>
📋 Completed Task
</h3>

<h2>
<?=$staff['task_completed']?>
</h2>

</div>




<div class="card">

<h3>
⚠️ Solved Complaint
</h3>

<h2>
<?=$solved_complaint?>
</h2>

</div>




<div class="card">

<h3>
📈 Task Completion
</h3>

<h2>
<?=$task_percent?>%
</h2>

</div>




<div class="card">

<h3>
⭐ Rating
</h3>

<h2>
<?=$staff['rating']?>/5
</h2>

</div>



</div>




<h3>
📋 Task Progress
</h3>


<div class="progress">

<div class="bar"
style="width:<?=$task_percent?>%">
</div>

</div>


<p>

<?=$staff['task_completed']?> /
<?=$staff['total_tasks']?>
Completed

</p>




<h3>
⚠️ Complaint Progress
</h3>


<div class="progress">

<div class="bar"
style="width:<?=$complaint_percent?>%">
</div>

</div>


<p>

<?=$solved_complaint?> /
<?=$total_complaint?>
Solved

</p>




<div class="feedback">


<h3>
💬 Admin Feedback
</h3>


<form method="POST" action="save_feedback.php">


<input type="hidden"
name="staff_id"
value="<?=$staff['staff_record_id']?>">


<label>
Performance Status
</label>


<select name="performance_status">


<option>
Excellent
</option>


<option selected>
Good
</option>


<option>
Average
</option>


<option>
Poor
</option>


</select>



<label>
Rating
</label>


<select name="rating">


<?php

for($i=5;$i>=1;$i--){

?>

<option value="<?=$i?>">

<?=$i?> ⭐

</option>


<?php } ?>


</select>



<label>
Feedback
</label>


<textarea name="feedback"
placeholder="Write feedback..."><?=h($staff['feedback'])?></textarea>



<br><br>


<button>

💾 Save Feedback

</button>



</form>


</div>



</div>



<?php } ?>



</div>


</body>

</html>